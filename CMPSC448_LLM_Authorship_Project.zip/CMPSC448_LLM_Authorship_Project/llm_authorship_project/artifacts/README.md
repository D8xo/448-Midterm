# Saved experiment details

I kept the results and information needed to check my project in this folder. `all_metrics.json` has my test scores and model comparisons. `splits.json` lists the question groups I used for training, validation, and testing. `run_config.json` has the training settings, `dataset_summary.json` has the data counts, and `source_provenance.json` records the original files and their checksums.
