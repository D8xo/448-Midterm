#!/usr/bin/env python3
"""One-command CMPSC 448 RQ1/RQ2/RQ3/RQ4 study and final PDF generation."""
from __future__ import annotations

import argparse
import json
import shutil
from datetime import datetime, timezone
from pathlib import Path

from src.data import audit_local_files, download_data, prepare_dataset, question_splits, domain_splits
from src.experiments import (make_results_figures, run_stylometry, seed_everything,
                             train_evaluate)
from src.report import make_report

ROOT = Path(__file__).resolve().parent


def run():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--download", action="store_true", help="Download authentic public MT-Bench files")
    ap.add_argument("--prepare-only", action="store_true", help="Only download/prepare and validate data")
    ap.add_argument("--epochs", type=int, default=8)
    ap.add_argument("--batch-size", type=int, default=32)
    ap.add_argument("--max-tokens", type=int, default=192)
    ap.add_argument("--vocab-size", type=int, default=16000)
    ap.add_argument("--lr", type=float, default=0.002)
    ap.add_argument("--patience", type=int, default=3)
    ap.add_argument("--seed", type=int, default=448)
    ap.add_argument("--author", default="Ata Dural", help="Change to match your actual report name")
    ap.add_argument("--heldout-domain", default="writing")
    args = ap.parse_args()
    if args.max_tokens < 64 or args.epochs < 1:
        ap.error("--max-tokens must be >=64 and --epochs >=1")
    raw = ROOT / "data" / "raw"
    prep = ROOT / "data" / "prepared"
    out = ROOT / "results"
    out.mkdir(parents=True, exist_ok=True)
    seed_everything(args.seed)
    if args.download:
        print("Downloading source material from LMSYS FastChat / MT-Bench...", flush=True)
        provenance = download_data(raw)
    else:
        if not (raw / "question.jsonl").exists():
            ap.error("Missing MT-Bench JSONL. Run: python run_all.py --download")
        audit_local_files(raw)
    df = prepare_dataset(raw, prep)
    summary = json.loads((prep / "dataset_summary.json").read_text(encoding="utf-8"))
    print("Verified paired dataset:", json.dumps(summary, indent=2), flush=True)
    if args.prepare_only:
        print("Data preparation finished; no training started.")
        return
    config = {
        "seed": args.seed, "epochs": args.epochs, "batch_size": args.batch_size,
        "max_tokens": args.max_tokens, "vocab_size": args.vocab_size,
        "lr": args.lr, "patience": args.patience,
    }
    (out / "run_config.json").write_text(json.dumps(config, indent=2), encoding="utf-8")
    splits = question_splits(df, args.seed)
    domain = domain_splits(df, args.heldout_domain, args.seed)
    (out / "splits.json").write_text(json.dumps({"main": splits, "domain": domain}, indent=2), encoding="utf-8")
    print("Main question-group split sizes:", {k: len(v) for k, v in splits.items()}, flush=True)
    print("Held-out domain:", args.heldout_domain, {k: len(v) for k, v in domain.items()}, flush=True)
    results = {
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "data_summary": summary, "training_config": config, "heldout_domain": args.heldout_domain,
        "main": {}, "domain": {},
    }
    for arch in ["CNN", "LSTM"]:
        for condition in ["input", "output", "input+output"]:
            key = f"{arch}_{condition}"
            print("\n[PRIMARY]", key, flush=True)
            results["main"][key] = train_evaluate(
                df, splits, arch, condition, out, config, key
            )
    for arch in ["CNN", "LSTM"]:
        print("\n[DOMAIN]", arch, args.heldout_domain, flush=True)
        results["domain"][arch] = train_evaluate(
            df, domain, arch, "output", out, config, f"{arch}_heldout_{args.heldout_domain}"
        )
    print("\n[STYLOMETRY] Computing features and logistic regression baseline", flush=True)
    results["stylometry"] = run_stylometry(df, splits, out, args.seed)
    print("\n[ABLATION] Removing formatting and retraining CNN", flush=True)
    results["ablation"] = train_evaluate(
        df, splits, "CNN", "output", out, config, "CNN_output_no_formatting", ablate=True
    )
    (out / "all_metrics.json").write_text(json.dumps(results, indent=2), encoding="utf-8")
    make_results_figures(results, out)
    report_path = make_report(
        out / "CMPSC448_Project_Report.pdf", summary, results, author=args.author,
        image_dir=out,
    )
    report_dir = ROOT / "report"
    report_dir.mkdir(exist_ok=True)
    final_copy = report_dir / "CMPSC448_Project_Report.pdf"
    shutil.copy2(report_path, final_copy)
    audit_dir = ROOT / "artifacts"
    audit_dir.mkdir(exist_ok=True)
    for source, dest_name in [
        (out / "all_metrics.json", "all_metrics.json"),
        (out / "splits.json", "splits.json"),
        (out / "run_config.json", "run_config.json"),
        (prep / "dataset_summary.json", "dataset_summary.json"),
        (raw / "provenance.json", "source_provenance.json"),
    ]:
        if source.exists():
            shutil.copy2(source, audit_dir / dest_name)
    print("\nFinished. Report:", report_path, flush=True)
    print("GitHub-ready report copy:", final_copy, flush=True)
    print("Complete metrics:", out / "all_metrics.json", flush=True)


if __name__ == "__main__":
    run()
