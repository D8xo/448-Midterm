"""Train the models, measure their results, and create the figures."""
from __future__ import annotations

import copy
import json
import random
import re
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import torch
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (accuracy_score, classification_report, confusion_matrix,
                             f1_score)
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from torch import nn
from torch.utils.data import DataLoader

from src.data import FAMILY_ORDER, partition, strip_formatting
from src.models import TOKEN_RE, TextDataset, Vocabulary, create_model


def seed_everything(seed: int):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.set_num_threads(min(3, torch.get_num_threads()))
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
        torch.backends.cudnn.deterministic = True
        torch.backends.cudnn.benchmark = False


def truncate_tokens(text: str, n: int) -> str:
    """Preserve newlines and spacing while using identical input/output token budgets."""
    matches = list(TOKEN_RE.finditer(str(text)))
    if not matches:
        return ""
    return str(text)[: matches[min(n, len(matches)) - 1].end()]


def assemble_text(frame: pd.DataFrame, condition: str, ablate: bool = False,
                  max_tokens: int = 192) -> list[str]:
    # Keep the answer length the same when comparing responses with combined inputs.
    prompt_budget = min(48, max(8, max_tokens // 4))
    output_budget = max(16, max_tokens - prompt_budget - 8)
    outputs = frame.output.map(strip_formatting) if ablate else frame.output
    prompts = [truncate_tokens(s, prompt_budget) for s in frame.prompt.astype(str)]
    answers = [truncate_tokens(s, output_budget) for s in outputs.astype(str)]
    if condition == "input":
        return prompts
    if condition == "output":
        return answers
    if condition == "input+output":
        return ["[USER] " + p + " [ASSISTANT] " + o
                for p, o in zip(prompts, answers)]
    raise ValueError("Unknown text condition")


def bootstrap_ci(y, pred, group_ids, seed=448, n_boot=500):
    """Question-cluster bootstrap; the two turns and six model outputs stay together."""
    rng = np.random.default_rng(seed)
    y = np.asarray(y)
    pred = np.asarray(pred)
    groups = np.asarray(group_ids)
    unique = np.unique(groups)
    by_group = {k: np.flatnonzero(groups == k) for k in unique}
    values = []
    for _ in range(n_boot):
        picked = rng.choice(unique, size=len(unique), replace=True)
        indices = np.concatenate([by_group[k] for k in picked])
        values.append(accuracy_score(y[indices], pred[indices]))
    return [float(np.percentile(values, 2.5)), float(np.percentile(values, 97.5))]


def measure(y, pred, frame: pd.DataFrame, seed: int):
    metrics = {
        "n_examples": len(y),
        "n_question_groups": int(frame.question_id.nunique()),
        "accuracy": float(accuracy_score(y, pred)),
        "macro_f1": float(f1_score(y, pred, average="macro", zero_division=0)),
        "weighted_f1": float(f1_score(y, pred, average="weighted", zero_division=0)),
        "confusion_matrix": confusion_matrix(y, pred, labels=[0, 1, 2]).tolist(),
        "per_family": classification_report(y, pred, target_names=FAMILY_ORDER,
                                            labels=[0, 1, 2], output_dict=True,
                                            zero_division=0),
        "accuracy_95pct_bootstrap_ci": bootstrap_ci(y, pred, frame.question_id, seed),
    }
    return metrics


def train_evaluate(df: pd.DataFrame, splits: dict, arch: str, condition: str,
                   output_dir: Path, config: dict, tag: str, ablate: bool = False):
    seed = config["seed"]
    seed_everything(seed)
    train = partition(df, splits, "train")
    val = partition(df, splits, "val")
    test = partition(df, splits, "test")
    train_text = assemble_text(train, condition, ablate, config["max_tokens"])
    val_text = assemble_text(val, condition, ablate, config["max_tokens"])
    test_text = assemble_text(test, condition, ablate, config["max_tokens"])
    vocab = Vocabulary.build(train_text, max_vocab=config["vocab_size"], min_freq=2)
    labels = {family: index for index, family in enumerate(FAMILY_ORDER)}
    make_data = lambda f, t: TextDataset(t, f.family.map(labels).tolist(), vocab, config["max_tokens"])
    ds_train, ds_val, ds_test = (make_data(train, train_text), make_data(val, val_text),
                                 make_data(test, test_text))
    loader_train = DataLoader(ds_train, batch_size=config["batch_size"], shuffle=True,
                              generator=torch.Generator().manual_seed(seed))
    loader_val = DataLoader(ds_val, batch_size=config["batch_size"], shuffle=False)
    loader_test = DataLoader(ds_test, batch_size=config["batch_size"], shuffle=False)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = create_model(arch, len(vocab)).to(device)
    optimizer = torch.optim.AdamW(model.parameters(), lr=config["lr"], weight_decay=0.01)
    loss_fn = nn.CrossEntropyLoss()
    best_state, best_score, wait = None, -1.0, 0
    history = []
    for epoch in range(1, config["epochs"] + 1):
        model.train()
        cum_loss, total = 0.0, 0
        for ids, lengths, y in loader_train:
            ids, lengths, y = ids.to(device), lengths.to(device), y.to(device)
            optimizer.zero_grad(set_to_none=True)
            logits = model(ids, lengths)
            loss = loss_fn(logits, y)
            loss.backward()
            nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            optimizer.step()
            cum_loss += loss.item() * len(y)
            total += len(y)
        true, pred = predict(model, loader_val, device)
        val_f1 = float(f1_score(true, pred, average="macro", zero_division=0))
        history.append({"epoch": epoch, "train_loss": cum_loss / max(1, total), "val_macro_f1": val_f1})
        print(f"  {tag:<23} epoch {epoch:02d} loss={cum_loss/max(1,total):.3f} val_f1={val_f1:.3f}", flush=True)
        if val_f1 > best_score + 1e-5:
            best_score = val_f1
            best_state = copy.deepcopy(model.state_dict())
            best_epoch = epoch
            wait = 0
        else:
            wait += 1
            if wait >= config["patience"]:
                break
    model.load_state_dict(best_state)
    y_test, y_pred = predict(model, loader_test, device)
    result = measure(y_test, y_pred, test, seed)
    result.update({"experiment": tag, "architecture": arch, "condition": condition,
                   "ablation": ablate, "best_epoch": best_epoch, "val_best_macro_f1": best_score,
                   "train_n": len(train), "val_n": len(val), "test_n": len(test),
                   "vocab_size": len(vocab), "parameters": sum(p.numel() for p in model.parameters()),
                   "history": history})
    output_dir.mkdir(parents=True, exist_ok=True)
    torch.save({"architecture": arch, "model_state": best_state, "vocab": vocab.stoi,
                "config": config, "classes": FAMILY_ORDER, "condition": condition,
                "ablation": ablate}, output_dir / f"{tag}.pt")
    pd.DataFrame({"record_id": test.record_id, "question_id": test.question_id,
                  "category": test.category, "model_id": test.model_id,
                  "true_family": test.family,
                  "predicted_family": [FAMILY_ORDER[int(k)] for k in y_pred]}).to_csv(
        output_dir / f"{tag}_predictions.csv", index=False)
    with (output_dir / f"{tag}.json").open("w", encoding="utf-8") as f:
        json.dump(result, f, indent=2)
    fig, ax = plt.subplots(figsize=(4.5, 3.3))
    confusion = np.asarray(result["confusion_matrix"])
    ax.imshow(confusion, cmap="Blues")
    ax.set_xticks(range(3), FAMILY_ORDER)
    ax.set_yticks(range(3), FAMILY_ORDER)
    ax.set_xlabel("Predicted model family")
    ax.set_ylabel("True model family")
    text_name = {"input": "prompts", "output": "responses", "input+output": "prompts and responses"}[condition]
    title = f"{arch} using {text_name}"
    if ablate:
        title += " without formatting"
    ax.set_title(f"{title} | {result['accuracy']:.1%} accuracy")
    for i in range(3):
        for j in range(3):
            ax.text(j, i, str(confusion[i, j]), ha="center", va="center",
                    color="white" if confusion[i, j] > confusion.max() * 0.55 else "black")
    fig.tight_layout()
    fig.savefig(output_dir / f"{tag}_confusion.png", dpi=170)
    plt.close(fig)
    return result


@torch.no_grad()
def predict(model, loader, device):
    model.eval()
    ys, preds = [], []
    for ids, lengths, y in loader:
        logits = model(ids.to(device), lengths.to(device))
        ys.extend(y.numpy().tolist())
        preds.extend(logits.argmax(dim=1).cpu().numpy().tolist())
    return np.array(ys), np.array(preds)


FEATURES = ["word_count", "char_count", "mean_word_length", "lexical_diversity",
            "line_count", "bullet_line_count", "heading_line_count", "code_fence_count",
            "digit_fraction", "punct_fraction", "first_person_fraction", "apology_count"]


def stylometric_features(output: str) -> dict[str, float]:
    """Observable output-only stylometry, no user prompt or label information."""
    s = str(output)
    words = re.findall(r"\b\w+\b", s.lower())
    lines = s.splitlines()
    chars = max(1, len(s))
    denom = max(1, len(words))
    bullet = sum(bool(re.match(r"^\s*(?:[-*+]\s|\d+[.)]\s|[\u2022]\s)", line)) for line in lines)
    headers = sum(bool(re.match(r"^\s*#{1,6}\s", line)) for line in lines)
    return {
        "word_count": float(len(words)), "char_count": float(len(s)),
        "mean_word_length": float(sum(len(w) for w in words) / denom),
        "lexical_diversity": float(len(set(words)) / denom),
        "line_count": float(len(lines)), "bullet_line_count": float(bullet),
        "heading_line_count": float(headers), "code_fence_count": float(s.count("```")),
        "digit_fraction": float(sum(c.isdigit() for c in s) / chars),
        "punct_fraction": float(sum((not c.isalnum()) and (not c.isspace()) for c in s) / chars),
        "first_person_fraction": float(sum(w in {"i", "me", "my", "mine"} for w in words) / denom),
        "apology_count": float(sum(w in {"sorry", "apologize", "apologies"} for w in words)),
    }


def run_stylometry(df: pd.DataFrame, splits: dict, output_dir: Path, seed=448):
    feat = pd.DataFrame([stylometric_features(s) for s in df.output])
    frame = pd.concat([df[["record_id", "family", "category", "question_id"]].reset_index(drop=True), feat], axis=1)
    frame.to_csv(output_dir / "rq4_stylometry.csv", index=False)
    summary = frame.groupby("family")[FEATURES].agg(["mean", "median"]).round(3)
    summary.to_csv(output_dir / "rq4_feature_summary.csv")
    train = frame[frame.question_id.isin(splits["train"])]
    test = frame[frame.question_id.isin(splits["test"])]
    labels = {family: index for index, family in enumerate(FAMILY_ORDER)}
    pipeline = make_pipeline(StandardScaler(), LogisticRegression(max_iter=2000, random_state=seed))
    pipeline.fit(train[FEATURES], train.family.map(labels))
    y = test.family.map(labels).to_numpy()
    pred = pipeline.predict(test[FEATURES])
    score = measure(y, pred, test, seed)
    score["description"] = "Standardized output-only stylometry + multinomial logistic regression"
    feature_means = {family: {feature: float(frame[frame.family == family][feature].mean())
                              for feature in FEATURES} for family in FAMILY_ORDER}
    data = {"feature_baseline": score, "mean_by_family": feature_means, "features": FEATURES}
    (output_dir / "rq4_stylometry_results.json").write_text(json.dumps(data, indent=2), encoding="utf-8")
    fig, ax = plt.subplots(figsize=(7.5, 3.6))
    groups = [np.clip(frame[frame.family == cls].word_count.to_numpy(), 0, None) for cls in FAMILY_ORDER]
    ax.boxplot(groups, tick_labels=FAMILY_ORDER, showfliers=False)
    ax.set_title("RQ4: Response length for each model family")
    ax.set_ylabel("Number of words")
    fig.tight_layout()
    fig.savefig(output_dir / "rq4_length.png", dpi=170)
    plt.close(fig)
    return data


def make_results_figures(results: dict, output_dir: Path):
    main = results["main"]
    fig, ax = plt.subplots(figsize=(7.5, 3.8))
    for i, arch in enumerate(("CNN", "LSTM")):
        keys = ["input", "output", "input+output"]
        ys = [main[f"{arch}_{cond}"]["macro_f1"] for cond in keys]
        xx = np.arange(3) + i * 0.35
        ax.bar(xx, ys, width=.35, label=arch)
    ax.set_xticks(np.arange(3) + .175, ["Input only", "Output only", "Input + output"])
    ax.set_ylabel("Test Macro F1")
    ax.set_ylim(0, 1.0)
    ax.set_title("RQ2: Comparing prompts and responses")
    ax.legend()
    fig.tight_layout()
    fig.savefig(output_dir / "rq2_main_comparison.png", dpi=170)
    plt.close(fig)
    fig, ax = plt.subplots(figsize=(6.8, 3.6))
    keys = ["CNN", "LSTM"]
    vals = [results["domain"][arch]["macro_f1"] for arch in keys]
    ax.bar(keys, vals)
    ax.set_ylim(0, 1)
    ax.set_ylabel("Writing test Macro F1")
    ax.set_title("RQ3: Results on writing questions")
    fig.tight_layout()
    fig.savefig(output_dir / "rq3_heldout_writing.png", dpi=170)
    plt.close(fig)
    fig, ax = plt.subplots(figsize=(6.4, 3.4))
    original = main["CNN_output"]["macro_f1"]
    ablated = results["ablation"]["macro_f1"]
    ax.bar(["Original output", "No Markdown markers"], [original, ablated])
    ax.set_ylim(0, 1)
    ax.set_ylabel("Test Macro F1")
    ax.set_title("RQ4: CNN scores after removing formatting")
    fig.tight_layout()
    fig.savefig(output_dir / "rq4_ablation.png", dpi=170)
    plt.close(fig)
