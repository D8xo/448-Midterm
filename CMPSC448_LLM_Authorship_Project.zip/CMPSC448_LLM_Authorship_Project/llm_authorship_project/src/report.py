"""Build the PDF report from saved experiment results."""
from __future__ import annotations

from datetime import date
from pathlib import Path
from xml.sax.saxutils import escape

from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER
from reportlab.lib.pagesizes import letter
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.platypus import (
    BaseDocTemplate, Frame, Image, KeepTogether, PageBreak, PageTemplate,
    Paragraph, Spacer, Table, TableStyle,
)
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont

INK = colors.HexColor("#182436")
NAVY = colors.HexColor("#193757")
TEAL = colors.HexColor("#177E86")
PALE = colors.HexColor("#F2F6F8")
LIGHT = colors.HexColor("#DAE3E9")
GRAY = colors.HexColor("#5E6A75")
PAGE_W, PAGE_H = letter


def register_fonts():
    fonts = Path("/usr/share/fonts/truetype/dejavu")
    if (fonts / "DejaVuSans.ttf").exists():
        pdfmetrics.registerFont(TTFont("DejaVu", str(fonts / "DejaVuSans.ttf")))
        pdfmetrics.registerFont(TTFont("DejaVu-Bold", str(fonts / "DejaVuSans-Bold.ttf")))
        return "DejaVu", "DejaVu-Bold"
    return "Helvetica", "Helvetica-Bold"


class AcademicDoc(BaseDocTemplate):
    def __init__(self, filename: str, draft: bool, font: str):
        super().__init__(filename, pagesize=letter, leftMargin=58, rightMargin=58,
                         topMargin=62, bottomMargin=60,
                         title="Who Wrote It? Identifying LLMs from Their Responses",
                         author="CMPSC 448 Project")
        self.draft, self.body_font = draft, font
        frame = Frame(self.leftMargin, self.bottomMargin, self.width, self.height,
                      leftPadding=0, bottomPadding=0, rightPadding=0, topPadding=0)
        self.addPageTemplates(PageTemplate(id="every", frames=[frame], onPage=self.draw_page))

    def draw_page(self, canvas, doc):
        canvas.saveState()
        canvas.setStrokeColor(LIGHT)
        canvas.line(58, 44, PAGE_W-58, 44)
        canvas.setFont(self.body_font, 7.5)
        canvas.setFillColor(GRAY)
        canvas.drawString(58, 30, "CMPSC 448 | Identifying LLMs from their responses")
        canvas.drawRightString(PAGE_W - 58, 30, f"Page {doc.page}")
        if self.draft:
            canvas.setFont(self.body_font, 7)
            canvas.setFillColor(colors.HexColor("#A26324"))
            canvas.drawRightString(PAGE_W - 58, PAGE_H - 32, "DRAFT: RESULTS NOT READY")
        canvas.restoreState()


def make_report(path: Path, summary: dict | None, results: dict | None, author="Ata Dural",
                title_date: str | None = None, image_dir: Path | None = None):
    """Build the report with the results that are available."""
    path.parent.mkdir(parents=True, exist_ok=True)
    font, bold = register_fonts()
    s = getSampleStyleSheet()
    s.add(ParagraphStyle(name="CoverTitleX", fontName=bold, fontSize=22,
                         leading=28, textColor=NAVY, spaceAfter=18))
    s.add(ParagraphStyle(name="SubX", fontName=font, fontSize=11, leading=16,
                         textColor=GRAY, spaceAfter=10))
    s.add(ParagraphStyle(name="HeadingX", fontName=bold, fontSize=13,
                         leading=18, spaceBefore=15, spaceAfter=6, textColor=NAVY,
                         keepWithNext=True))
    s.add(ParagraphStyle(name="SmallHeadX", fontName=bold, fontSize=10.5,
                         leading=15, spaceBefore=9, spaceAfter=4, textColor=TEAL,
                         keepWithNext=True))
    s.add(ParagraphStyle(name="BodyX", fontName=font, fontSize=9.1,
                         leading=14.1, textColor=INK, spaceAfter=6))
    s.add(ParagraphStyle(name="SmallX", fontName=font, fontSize=8.1,
                         leading=12.2, textColor=GRAY, spaceAfter=6))
    s.add(ParagraphStyle(name="CellX", fontName=font, fontSize=7.5,
                         leading=11.4, textColor=INK))
    s.add(ParagraphStyle(name="CellBoldX", fontName=bold, fontSize=7.5,
                         leading=11.4, textColor=colors.white))
    s.add(ParagraphStyle(name="CaptionX", fontName=font, fontSize=8,
                         leading=12, alignment=TA_CENTER, textColor=GRAY, spaceAfter=10))
    p = lambda text, style="BodyX": Paragraph(text, s[style])
    story = []
    draft = results is None

    def head(text):
        story.append(p(escape(text), "HeadingX"))

    def sub(text):
        story.append(p(escape(text), "SmallHeadX"))

    def para(text):
        story.append(p(text))

    def data_table(headers, rows, widths=None, compact=False):
        table_rows = [[p(escape(str(x)), "CellBoldX") for x in headers]]
        for row in rows:
            table_rows.append([p(escape(str(x)), "CellX") for x in row])
        table = Table(table_rows, colWidths=widths, repeatRows=1, hAlign="LEFT")
        cell_padding = 4 if compact else 7
        table.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (-1, 0), NAVY),
            ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, PALE]),
            ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
            ("TOPPADDING", (0, 0), (-1, -1), cell_padding),
            ("BOTTOMPADDING", (0, 0), (-1, -1), cell_padding),
            ("LEFTPADDING", (0, 0), (-1, -1), 9),
            ("RIGHTPADDING", (0, 0), (-1, -1), 9),
            ("LINEBELOW", (0, -1), (-1, -1), 0.4, LIGHT),
        ]))
        story.append(table)
        story.append(Spacer(1, 10))

    def figure(filename, caption, w=440):
        if image_dir is None:
            return
        file = image_dir / filename
        if not file.exists():
            return
        from PIL import Image as PILImage
        with PILImage.open(file) as im:
            iw, ih = im.size
        h = w * ih / iw
        if h > 285:
            h, w = 285, w * 285 / h
        story.append(KeepTogether([Image(str(file), width=w, height=h), p(escape(caption), "CaptionX")]))

    title_date = title_date or date.today().strftime("%B %d, %Y")
    story.append(Spacer(1, 43))
    story.append(p("WHO WROTE IT?", "CoverTitleX"))
    story.append(p("Identifying LLM Families from Their Responses", "CoverTitleX"))
    story.append(p("CMPSC 448 | Midterm Project Report", "SubX"))
    story.append(Spacer(1, 5))
    data_table(["Project information", "Details"], [
        ("Team leader and author", author),
        ("Model families", "GPT, Claude, and Llama"),
        ("Required models", "Convolutional Neural Network (CNN) and a recurrent network using LSTM"),
        ("Research questions", "RQ1, RQ2, RQ3, and RQ4, including both extra credit questions"),
        ("Report prepared", title_date),
        ("Presentation", "No presentation"),
        ("Status", "All experiments completed" if results else "Experiments not yet run"),
    ], widths=[160, 336])
    story.append(Spacer(1, 16))
    if draft:
        para("I have prepared the project code, but I have not run the full experiments yet. "
             "This draft explains my method without reporting test scores.")
    else:
        para("The results in this report come from the saved experiments. Each model was tested "
             "on questions that were kept out of its training and validation data.")
    head("Abstract")
    para("For this project, I tested whether a CNN and an LSTM could tell which model family "
         "wrote a response. I used answers from GPT, Claude, and Llama in the public MT Bench "
         "dataset. Each family had two model versions, and all six versions answered the same "
         "questions. I kept answers to each question together when I divided the data for "
         "training, validation, and testing. I also checked whether including the prompt helped, "
         "whether the models could handle writing tasks they had not trained on, and whether "
         "response length and formatting helped identify the family.")
    if results:
        strongest = max(
            (results["main"][f"{model}_output"] for model in ("CNN", "LSTM")),
            key=lambda result: result["accuracy"],
        )
        para(f"Using responses alone, the {strongest['architecture']} had the higher accuracy "
             f"at <b>{strongest['accuracy']:.1%}</b>, with a Macro F1 score of "
             f"<b>{strongest['macro_f1']:.3f}</b>. These results apply to this dataset. "
             "They do not prove that the same approach can identify the source of any AI response.")
    story.append(PageBreak())

    head("1. Problem and research questions")
    para("I wanted to identify whether a response came from GPT, Claude, or Llama. I compared "
         "using the user's prompt alone, the response alone, and both together. This project "
         "does not try to tell human writing from AI writing.")
    data_table(["Research question", "What I tested"], [
        ("RQ1 (required)", "Compare the CNN and LSTM using only the response."),
        ("RQ2 (required)", "Train both models on the prompt alone, the response alone, and both together."),
        ("RQ3 (+5)", "Train on tasks other than writing, then test on writing questions."),
        ("RQ4 (+5)", "Compare response features, test a simpler model, and train the CNN again after removing formatting."),
    ], [125, 371])

    head("2. Data source and preparation")
    para("I used the public MT Bench files in the LMSYS FastChat repository [1, 2]. "
         "The <b>question.jsonl</b> file contains the prompts and task categories. "
         "Six files in <b>model_answer</b> contain the answers. I kept the first recorded answer "
         "choice and included only questions with both turns available for all six model "
         "versions. The data came from a public test set, not private chats.")
    data_table(["Family", "Model versions"], [
        ("GPT", "GPT 3.5 Turbo and GPT 4"),
        ("Claude", "Claude v1 and Claude Instant v1"),
        ("Llama", "Llama 2 7B Chat and Llama 2 13B Chat"),
    ], [130, 366])
    if summary:
        para(f"The final dataset contains <b>{summary['rows']:,} responses</b> from "
             f"<b>{summary['unique_questions']} questions</b>. Each family has "
             f"<b>{summary['by_family']['GPT']}</b> responses, so the three families "
             "are equally represented.")
        data_table(["Task category", "Responses"],
                   [(category, str(count)) for category, count in sorted(summary["by_category"].items())],
                   [300, 196], compact=True)
    else:
        para("The source has 80 questions across eight task categories. If I have both answer "
             "turns from all six model versions, I can use 960 responses in total.")
    para("The processed CSV stores the question ID, task category, turn, model family, original "
         "model ID, prompt, and response. I also saved the source links and SHA256 file "
         "checksums, which can be used to check whether a file has changed. No user IP "
         "addresses or personal identifiers were collected. Anyone sharing the raw responses "
         "should first check the dataset license and the terms for the original models.")

    head("3. Keeping training and test questions separate")
    para("I grouped the data by question ID so that all six model versions and both turns "
         "stayed together. I used 60% of the question groups for training, 20% for validation, "
         "and 20% for testing, with all eight task categories represented in each set. I used "
         "random seed 448 and kept the same split for the main comparisons and the formatting "
         "test. This kept answers to a test question out of the training data.")
    para("For tests using only prompts, I did not include any model answers. For the second "
         "turn, I used both user prompts. Since each family received the same questions, "
         "I expected prompts alone to perform around the 33.3% chance level. A much higher "
         "score would be a reason to check for mistakes in the data split or the code.")
    para("I report accuracy and Macro F1, along with scores for each family and tables of "
         "prediction counts. Accuracy is the share of predictions that are correct. Macro F1 "
         "gives each family equal weight when averaging its F1 score.")

    head("4. How I built and trained the models")
    para("Both models change text to lowercase and split words and punctuation into tokens, "
         "or small pieces of text. I built the vocabulary from training text only. Each token "
         "is represented by 64 learned values. Unknown tokens use &lt;UNK&gt;, and a separate "
         "padding token fills short inputs. Each input is limited to 192 tokens, with extra "
         "tokens cut from the end. Training batches contain 32 examples, and dropout is 0.35.")
    data_table(["Model", "How it works"], [
        ("CNN", "Uses filters over groups of 3, 5, or 7 tokens, with 96 filters for each size. "
                "ReLU keeps positive values. The model keeps the largest valid value from each "
                "filter, skips padding positions, applies dropout, and produces a score for each family."),
        ("LSTM", "Reads the text in both directions, with 64 hidden units in each direction. "
                 "It joins the final states from both directions, applies dropout, and produces "
                 "a score for each family."),
    ], [92, 404])
    para("I trained both models from scratch using cross entropy loss and AdamW. The learning "
         "rate was 0.002, and weight decay was 0.01. I limited the gradient norm to 1.0 to "
         "control large updates. Each run allowed up to eight passes through the training "
         "data and stopped after three passes without a better validation Macro F1 score. "
         "The main comparisons used the same random seed, training goal, data split, and "
         "training limit. Neither model used a pretrained language model.")

    head("5. RQ1 and RQ2: identifying the family and testing prompts")
    if results:
        condition_names = {
            "input": "Prompt only",
            "output": "Response only",
            "input+output": "Prompt and response",
        }
        rows = []
        for model in ("CNN", "LSTM"):
            for condition in ("input", "output", "input+output"):
                score = results["main"][f"{model}_{condition}"]
                low, high = score["accuracy_95pct_bootstrap_ci"]
                rows.append((model, condition_names[condition], f"{score['accuracy']:.1%}",
                             f"{score['macro_f1']:.3f}", f"{low:.1%} to {high:.1%}"))
        data_table(["Model", "Text used", "Accuracy", "Macro F1", "95% accuracy interval"],
                   rows, [75, 120, 85, 90, 126])
        figure("rq2_main_comparison.png", "Figure 1. Test scores using prompts, responses, or both.", 445)
        para("To estimate how much accuracy could vary, I sampled the test question groups "
             "with replacement 500 times and calculated a 95% confidence interval. I kept "
             "all answers to each question together rather than counting them as unrelated "
             "examples. These intervals do not cover changes to the dataset, model versions, "
             "or data source.")
        cnn, lstm = (results["main"][f"{model}_output"] for model in ("CNN", "LSTM"))
        para(f"<b>RQ1:</b> With responses alone, the CNN scored {cnn['accuracy']:.1%} accuracy "
             f"and {cnn['macro_f1']:.3f} Macro F1. The LSTM scored {lstm['accuracy']:.1%} "
             f"accuracy and {lstm['macro_f1']:.3f} Macro F1. The "
             f"{'CNN' if cnn['accuracy'] >= lstm['accuracy'] else 'LSTM'} did slightly better "
             "in this run, using the model versions from the 2023 dataset.")
        cnn_input = results["main"]["CNN_input"]
        lstm_input = results["main"]["LSTM_input"]
        cnn_change = results["main"]["CNN_input+output"]["macro_f1"] - cnn["macro_f1"]
        lstm_change = results["main"]["LSTM_input+output"]["macro_f1"] - lstm["macro_f1"]
        cnn_direction = "fell" if cnn_change < 0 else "rose"
        lstm_direction = "fell" if lstm_change < 0 else "rose"
        para(f"<b>RQ2:</b> The CNN reached {cnn_input['accuracy']:.1%} accuracy using only "
             f"prompts, and the LSTM reached {lstm_input['accuracy']:.1%}. "
             f"When I included both prompts and responses, the CNN's Macro F1 {cnn_direction} "
             f"by {abs(cnn_change):.3f}, and the LSTM's {lstm_direction} by "
             f"{abs(lstm_change):.3f}. These results do not tell me that adding prompts "
             "would have the same effect on other datasets.")
        figure("CNN_output_confusion.png",
               "Figure 2. CNN predictions using responses only. Rows show the actual family; columns show the predicted family.",
               335)
        figure("LSTM_output_confusion.png", "Figure 3. LSTM predictions using responses only.", 335)
    else:
        para("I have prepared the six main experiments for the CNN and LSTM, using prompts, "
             "responses, and both together. I will fill in the results after I run them.")

    head("6. RQ3 extra credit: testing on a new task")
    para("I used the task categories provided by MT Bench. I kept all 10 writing questions "
         "out of training and validation, then divided the other seven categories into "
         "training and validation sets. I trained both models using responses alone and "
         "tested them on the writing responses. The table compares validation scores on "
         "the other categories with test scores on writing. Since these are different "
         "sets of questions, the difference does not show that the task category alone "
         "caused a change in performance.")
    if results:
        data_table(["Model", "Other tasks: validation Macro F1", "Writing: test Macro F1", "Writing accuracy"], [
            (model, f"{results['domain'][model]['val_best_macro_f1']:.3f}",
             f"{results['domain'][model]['macro_f1']:.3f}",
             f"{results['domain'][model]['accuracy']:.1%}")
            for model in ("CNN", "LSTM")
        ], [88, 174, 142, 92])
        figure("rq3_heldout_writing.png", "Figure 4. Results on writing questions that were not used for training.", 425)
        cnn_writing = results["domain"]["CNN"]["accuracy"]
        lstm_writing = results["domain"]["LSTM"]["accuracy"]
        para(f"Both models scored above chance on the writing test, with {cnn_writing:.1%} "
             f"accuracy for the CNN and {lstm_writing:.1%} for the LSTM. This suggests "
             "that some useful patterns carried over to writing. The writing set was small, "
             "though, and differences in content or formatting could also affect the results.")
    else:
        para("I will report the writing test results after I train both models on the other tasks.")

    head("7. RQ4 extra credit: differences in the responses")
    para("I measured word and character counts, average word length, the share of unique "
         "words, line counts, list items, headings, code block markers, the share of digits "
         "and punctuation, how often the words I, me, my, and mine appeared, and apology "
         "terms. I compared the averages for each family. I also trained a simpler model "
         "called logistic regression using these measurements, scaled to comparable values. "
         "This tested whether basic response features could help identify the family "
         "without the CNN or LSTM.")
    para("I then removed Markdown and list markers, made spacing consistent, and trained "
         "the CNN again with the same data split and settings. This tested whether "
         "formatting helped the model. The changes could also affect code or math symbols, "
         "so a lower score would not prove that formatting alone caused the difference.")
    if results:
        features = results["stylometry"]
        baseline = features["feature_baseline"]
        cleaned = results["ablation"]
        reference = results["main"]["CNN_output"]
        data_table(["Test", "Accuracy", "Macro F1"], [
            ("Logistic regression using response features", f"{baseline['accuracy']:.1%}", f"{baseline['macro_f1']:.3f}"),
            ("CNN with original responses", f"{reference['accuracy']:.1%}", f"{reference['macro_f1']:.3f}"),
            ("CNN after removing formatting", f"{cleaned['accuracy']:.1%}", f"{cleaned['macro_f1']:.3f}"),
        ], [270, 113, 113])
        figure("rq4_length.png", "Figure 5. Response lengths for all examples in the dataset.", 445)
        figure("rq4_ablation.png", "Figure 6. CNN scores before and after removing formatting.", 430)
        means = features["mean_by_family"]
        data_table(["Family", "Average words", "Average share of unique words", "Average list lines"], [
            (family, f"{means[family]['word_count']:.1f}",
             f"{means[family]['lexical_diversity']:.3f}",
             f"{means[family]['bullet_line_count']:.2f}")
            for family in ("GPT", "Claude", "Llama")
        ], [110, 125, 146, 115])
        difference = cleaned["macro_f1"] - reference["macro_f1"]
        change_word = "fell" if difference < 0 else "rose"
        para(f"After formatting was removed, the CNN's Macro F1 {change_word} by "
             f"{abs(difference):.3f}. Llama had longer responses on average, while "
             "Claude had more list lines. Length and formatting seem useful for this "
             "dataset, but the task and the way a model follows instructions can also "
             "shape these features.")
    else:
        para("I will compare these response features and the formatting test after the "
             "experiments are complete.")

    head("8. Limits of the study")
    para("The dataset has 960 responses, but they come from only 80 questions in eight "
         "categories. Answers to the same question are related, so the response count "
         "does not mean there are 960 independent examples. The test results may change "
         "with a different set of questions.")
    para("I used older model versions from the dataset, not the latest releases. Each family "
         "includes only two versions. Their training and response settings may explain some "
         "of the differences. The dataset also does not cover the full range of everyday "
         "conversations.")
    para("The models may be recognizing response length, refusals, headings, or code "
         "formatting rather than a lasting sign of who wrote the text. The writing test "
         "and formatting test help check this concern, but they do not rule it out.")
    para("I used one random seed for the main runs. More seeds, different data splits, other "
         "public datasets, and tests on model versions not used during training would make "
         "the findings stronger. These results should not be used as proof of who wrote an "
         "individual response.")

    head("9. Lessons and experience")
    para("The main lesson for me was that the data split matters as much as the model. "
         "Answers to the same prompt need to stay together. Otherwise, a model could "
         "recognize a question it has already seen instead of learning differences "
         "between model families. Using the same prompts for every family also gave me "
         "a useful check: the prompt alone should not reveal the answer.")
    para("I also learned to make comparisons under the same conditions. I used the same "
         "data splits, built vocabularies from training text only, and chose models using "
         "validation scores. Accuracy alone did not explain what the models had learned, "
         "so I also looked at response features, tested writing tasks, and removed "
         "formatting. Saving the models, predictions, scores, and source details made it "
         "possible to check the results later.")

    head("10. Running the project and submitted files")
    para("The project uses Python 3.10 or newer. The setup steps are in <b>README.md</b>. "
         "After installing the packages in <b>requirements.txt</b>, I can run "
         "<b>python run_all.py --download</b>. It downloads seven public JSONL files, "
         "prepares the data, creates the question splits, and runs all the experiments. "
         "This includes six main CNN and LSTM runs, two writing tests, one CNN formatting "
         "test, and the response feature model. It saves the tables and figures and "
         "creates <b>report/CMPSC448_Project_Report.pdf</b>. The README also explains "
         "how to run with local data.")
    if summary:
        para(f"The dataset contains {summary['unique_questions']} question groups and "
             f"{summary['rows']} responses. There are {summary['exact_duplicate_outputs']} "
             "repeated response strings. I kept them so that each question still had the "
             "full set of paired model answers.")
    head("References")
    for item in [
        "[1] Zheng et al. (2023). Judging LLM as a Judge with MT Bench and Chatbot Arena. arXiv:2306.05685. https://arxiv.org/abs/2306.05685",
        "[2] LMSYS. FastChat public MT Bench questions and model answers. https://github.com/lm-sys/FastChat/tree/main/fastchat/llm_judge/data/mt_bench",
        "[3] LMSYS (2023). Chatbot Arena Week 8, introducing MT Bench. https://www.lmsys.org/blog/2023-06-22-leaderboard/",
    ]:
        story.append(p(escape(item), "SmallX"))
    doc = AcademicDoc(str(path), draft=draft, font=font)
    doc.build(story)
    return path
