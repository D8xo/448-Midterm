"""From-scratch PyTorch word-level CNN and bidirectional LSTM classifiers."""
from __future__ import annotations

import re
from collections import Counter

import torch
from torch import nn
from torch.utils.data import Dataset

TOKEN_RE = re.compile(r"\w+|[^\w\s]", flags=re.UNICODE)


def tokenize(text: str) -> list[str]:
    return TOKEN_RE.findall(str(text).lower())


class Vocabulary:
    def __init__(self, stoi: dict[str, int]):
        self.stoi = stoi

    @classmethod
    def build(cls, texts: list[str], max_vocab: int = 16000, min_freq: int = 2):
        counts = Counter(token for text in texts for token in tokenize(text))
        stoi = {"<PAD>": 0, "<UNK>": 1}
        for token, count in counts.most_common():
            if len(stoi) >= max_vocab:
                break
            if count >= min_freq:
                stoi[token] = len(stoi)
        return cls(stoi)

    def encode(self, text: str, max_len: int):
        tokens = tokenize(text)[:max_len]
        ids = [self.stoi.get(token, 1) for token in tokens]
        length = max(1, len(ids))
        return ids + [0] * (max_len - len(ids)), length

    def __len__(self):
        return len(self.stoi)


class TextDataset(Dataset):
    def __init__(self, texts, labels, vocab: Vocabulary, max_len: int):
        self.features = [vocab.encode(str(text), max_len) for text in texts]
        self.labels = [int(x) for x in labels]

    def __len__(self):
        return len(self.labels)

    def __getitem__(self, i):
        ids, length = self.features[i]
        return (torch.tensor(ids, dtype=torch.long),
                torch.tensor(length, dtype=torch.long),
                torch.tensor(self.labels[i], dtype=torch.long))


class CNNClassifier(nn.Module):
    def __init__(self, vocab_size, n_classes=3, embedding_dim=64, channels=96, dropout=0.35):
        super().__init__()
        self.embedding = nn.Embedding(vocab_size, embedding_dim, padding_idx=0)
        self.convs = nn.ModuleList([
            nn.Conv1d(embedding_dim, channels, kernel_size=k, padding="same")
            for k in (3, 5, 7)
        ])
        self.dropout = nn.Dropout(dropout)
        self.head = nn.Linear(3 * channels, n_classes)

    def forward(self, ids, lengths):
        x = self.embedding(ids).transpose(1, 2)
        features = []
        for conv in self.convs:
            activated = torch.relu(conv(x))
            valid = torch.arange(activated.shape[-1], device=ids.device)[None, :] < lengths[:, None]
            activated = activated.masked_fill(~valid[:, None, :], -1e4)
            features.append(activated.max(dim=-1).values)
        return self.head(self.dropout(torch.cat(features, dim=1)))


class LSTMClassifier(nn.Module):
    def __init__(self, vocab_size, n_classes=3, embedding_dim=64, hidden_size=64, dropout=0.35):
        super().__init__()
        self.embedding = nn.Embedding(vocab_size, embedding_dim, padding_idx=0)
        self.lstm = nn.LSTM(embedding_dim, hidden_size, batch_first=True, bidirectional=True)
        self.dropout = nn.Dropout(dropout)
        self.head = nn.Linear(2 * hidden_size, n_classes)

    def forward(self, ids, lengths):
        x = self.embedding(ids)
        packed = nn.utils.rnn.pack_padded_sequence(
            x, lengths.cpu(), batch_first=True, enforce_sorted=False
        )
        _, (h_n, _) = self.lstm(packed)
        representation = torch.cat((h_n[-2], h_n[-1]), dim=1)
        return self.head(self.dropout(representation))


def create_model(architecture: str, vocab_size: int, n_classes: int = 3):
    if architecture == "CNN":
        return CNNClassifier(vocab_size=vocab_size, n_classes=n_classes)
    if architecture == "LSTM":
        return LSTMClassifier(vocab_size=vocab_size, n_classes=n_classes)
    raise ValueError(f"Unknown architecture: {architecture}")
