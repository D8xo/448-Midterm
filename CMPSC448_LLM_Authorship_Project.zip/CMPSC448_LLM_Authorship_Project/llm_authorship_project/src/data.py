"""Download and prepare MT Bench questions and model responses."""
from __future__ import annotations

import csv
import hashlib
from datetime import datetime, timezone
import json
import re
import time
from pathlib import Path

import pandas as pd
import requests
from sklearn.model_selection import train_test_split

MODEL_FAMILIES = {
    "GPT": ["gpt-3.5-turbo", "gpt-4"],
    "Claude": ["claude-v1", "claude-instant-v1"],
    "Llama": ["Llama-2-7b-chat", "Llama-2-13b-chat"],
}
FAMILY_ORDER = ["GPT", "Claude", "Llama"]
DATA_ROOT = "fastchat/llm_judge/data/mt_bench"
SOURCES = [
    "https://raw.githubusercontent.com/lm-sys/FastChat/main/" + DATA_ROOT + "/{rel}",
    "https://huggingface.co/spaces/lmsys/mt-bench/resolve/main/data/mt_bench/{rel}",
]


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read_jsonl(path: Path) -> list[dict]:
    with path.open(encoding="utf-8") as f:
        return [json.loads(line) for line in f if line.strip()]


def download_data(raw_dir: Path, timeout: int = 45) -> dict:
    """Download source files, verify JSONL, and record provenance hashes."""
    raw_dir.mkdir(parents=True, exist_ok=True)
    files = ["question.jsonl"] + [
        "model_answer/" + model + ".jsonl"
        for models in MODEL_FAMILIES.values() for model in models
    ]
    manifest = {"dataset": "LMSYS MT-Bench", "source_repo": "lm-sys/FastChat",
                "source_base_urls": SOURCES, "audited_utc": datetime.now(timezone.utc).isoformat(),
                "files": {}}
    for relative in files:
        destination = raw_dir / relative
        destination.parent.mkdir(parents=True, exist_ok=True)
        if not destination.exists() or destination.stat().st_size < 100:
            errors = []
            for template in SOURCES:
                url = template.format(rel=relative)
                for retry in range(2):
                    try:
                        response = requests.get(
                            url, timeout=timeout, headers={"User-Agent": "CMPSC448-research/1.0"}
                        )
                        response.raise_for_status()
                        content = response.content
                        # Validate before saving; catches rate-limit and HTML errors.
                        lines = [line for line in content.splitlines() if line.strip()]
                        if len(lines) < 20 or not isinstance(json.loads(lines[0]), dict):
                            raise ValueError("Downloaded file does not contain expected JSONL")
                        destination.write_bytes(content)
                        break
                    except (requests.RequestException, ValueError) as exc:
                        errors.append(f"{url}: {str(exc)[:110]}")
                        time.sleep(0.5)
                if destination.exists() and destination.stat().st_size >= 100:
                    break
            else:
                raise RuntimeError(
                    "Could not download " + relative + ". Internet access required.\n" + "\n".join(errors)
                    + "\nAlternative: manually copy the MT-Bench JSONL files into data/raw/"
                )
        rows = read_jsonl(destination)
        if len(rows) < 20:
            raise ValueError(f"Too few JSONL rows in {destination}")
        manifest["files"][relative] = {"sha256": sha256(destination), "rows": len(rows)}
    (raw_dir / "provenance.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    return manifest


def prepare_dataset(raw_dir: Path, prepared_dir: Path) -> pd.DataFrame:
    """Keep only question IDs answered by all six models at both turns.

    The balanced full-crossing ensures that the same prompts are present for
    every model variant, avoiding prompt-label confounding in the source data.
    """
    questions = {int(row["question_id"]): row for row in read_jsonl(raw_dir / "question.jsonl")}
    answers: dict[str, dict[int, list[str]]] = {}
    for model in [m for variants in MODEL_FAMILIES.values() for m in variants]:
        file = raw_dir / "model_answer" / f"{model}.jsonl"
        if not file.exists():
            raise FileNotFoundError(f"Missing {file}; run with --download first")
        by_question = {}
        for item in read_jsonl(file):
            choices = item.get("choices") or []
            # Use the first answer choice for every model.
            selected = next((c for c in choices if c.get("index") == 0), None)
            if selected is None and choices:
                selected = choices[0]
            turns = selected.get("turns", []) if selected else []
            qid = int(item["question_id"])
            if len(turns) >= 2 and all(isinstance(t, str) and t.strip() for t in turns[:2]):
                by_question[qid] = turns[:2]
        answers[model] = by_question
    retained = sorted(set(questions).intersection(*(set(a) for a in answers.values())))
    if len(retained) < 40:
        raise ValueError(f"Expected >=40 fully paired questions; only found {len(retained)}")
    dataset = []
    for qid in retained:
        task = questions[qid]
        user_turns = task.get("turns", [])
        if len(user_turns) < 2:
            continue
        for turn in range(2):
            # Keep the earlier model answer out of the prompt only experiment.
            if turn == 0:
                prompt = user_turns[0]
            else:
                prompt = user_turns[0] + "\n\n[USER FOLLOW-UP]\n" + user_turns[1]
            for family, models in MODEL_FAMILIES.items():
                for model in models:
                    dataset.append({
                        "record_id": f"{qid}_{turn+1}_{model}",
                        "question_id": qid,
                        "category": task["category"],
                        "turn": turn + 1,
                        "family": family,
                        "model_id": model,
                        "prompt": prompt,
                        "output": answers[model][qid][turn],
                    })
    df = pd.DataFrame(dataset)
    if df.empty or df.duplicated("record_id").any():
        raise ValueError("Empty or duplicate dataset")
    families = df.groupby("family").size().to_dict()
    if set(families) != set(FAMILY_ORDER) or len(set(families.values())) != 1:
        raise ValueError(f"Class imbalance in paired dataset: {families}")
    # Each question needs two turns from all six model versions.
    expected = len([m for variants in MODEL_FAMILIES.values() for m in variants]) * 2
    sizes = df.groupby("question_id").size()
    if (sizes != expected).any():
        raise ValueError(f"Questions with incomplete model coverage: {sizes[sizes != expected]}")
    prepared_dir.mkdir(parents=True, exist_ok=True)
    df.to_csv(prepared_dir / "mtbench_llm_authorship.csv", index=False, quoting=csv.QUOTE_MINIMAL)
    summary = {
        "rows": len(df), "unique_questions": int(df.question_id.nunique()),
        "by_family": families, "by_model": df.model_id.value_counts().to_dict(),
        "by_category": df.category.value_counts().to_dict(),
        "categories": sorted(df.category.unique().tolist()),
        "exact_duplicate_outputs": int(df.output.duplicated().sum()),
        "source": "LMSYS MT-Bench model-answer JSONL files, only first choice, both turns",
    }
    (prepared_dir / "dataset_summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    return df


def question_splits(df: pd.DataFrame, seed: int = 448) -> dict[str, list[int]]:
    """Stratified 60/20/20 by QUESTION ID, not individual answer rows."""
    questions = df[["question_id", "category"]].drop_duplicates().sort_values("question_id")
    group_ids = questions.question_id.to_numpy()
    categories = questions.category.to_numpy()
    train_val, test = train_test_split(
        group_ids, test_size=0.2, stratify=categories, random_state=seed
    )
    category_map = questions.set_index("question_id").category.to_dict()
    train, val = train_test_split(
        train_val, test_size=0.25,
        stratify=[category_map[int(q)] for q in train_val], random_state=seed
    )
    result = {"train": sorted(map(int, train)), "val": sorted(map(int, val)), "test": sorted(map(int, test))}
    assert not (set(result["train"]) & set(result["val"]) | set(result["test"]) & set(result["val"]) | set(result["train"]) & set(result["test"]))
    return result


def domain_splits(df: pd.DataFrame, heldout: str = "writing", seed: int = 448) -> dict[str, list[int]]:
    """Train/validate on all other categories; test on writing only."""
    questions = df[["question_id", "category"]].drop_duplicates().sort_values("question_id")
    test = questions.loc[questions.category == heldout, "question_id"].tolist()
    pool = questions[questions.category != heldout]
    if not test or pool.category.nunique() < 2:
        raise ValueError(f"Missing held-out category {heldout} or training categories")
    train, val = train_test_split(
        pool.question_id.to_numpy(), test_size=0.2,
        stratify=pool.category.to_numpy(), random_state=seed
    )
    return {"train": sorted(map(int, train)), "val": sorted(map(int, val)), "test": sorted(map(int, test))}


def partition(df: pd.DataFrame, splits: dict, name: str) -> pd.DataFrame:
    return df[df.question_id.isin(splits[name])].sort_values(["question_id", "turn", "family", "model_id"]).reset_index(drop=True)


def strip_formatting(text: str) -> str:
    """Formatting ablation: remove Markdown/control markers, not lexical tokens."""
    text = re.sub(r"(?m)^\s{0,4}(?:\#{1,6}\s*|[>*-]\s+|\d{1,2}[.)]\s+)", " ", text)
    text = re.sub(r"[`*_~]", "", text)
    text = re.sub(r"\s+", " ", text)
    return text.strip()


def audit_local_files(raw_dir: Path) -> dict:
    """Hash and validate manually pre-placed authentic files in offline mode."""
    manifest = {"dataset": "LMSYS MT-Bench", "source_repo": "lm-sys/FastChat",
                "source_base_urls": SOURCES, "audited_utc": datetime.now(timezone.utc).isoformat(),
                "acquisition": "local files; original source must be verified by the operator",
                "files": {}}
    paths = ["question.jsonl"] + ["model_answer/" + m + ".jsonl"
                                  for variants in MODEL_FAMILIES.values() for m in variants]
    for relative in paths:
        file = raw_dir / relative
        if not file.exists():
            raise FileNotFoundError(f"Missing MT-Bench source file: {file}")
        rows = read_jsonl(file)
        if len(rows) < 20:
            raise ValueError(f"Invalid/too short JSONL file: {file}")
        manifest["files"][relative] = {"sha256": sha256(file), "rows": len(rows)}
    (raw_dir / "provenance.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    return manifest
