"""CMPSC 448 LLM authorship classification study."""
