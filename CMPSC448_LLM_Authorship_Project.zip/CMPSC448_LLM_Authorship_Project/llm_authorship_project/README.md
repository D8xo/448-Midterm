# Who Wrote It? Identifying LLMs from Their Responses

CMPSC 448 Midterm Project, Fall 2026  
Author: Ata Dural

## About my project

For this project, I wanted to see whether I could tell which AI model family wrote a response. I worked with three families: GPT, Claude, and Llama. I used a public dataset called MT Bench and collected 960 responses, with 320 responses from each family.

I trained two models, a Convolutional Neural Network (CNN) and a Long Short Term Memory network (LSTM). I compared their results and looked at whether the original question helped identify the model. I also completed both extra credit questions. I chose not to give a presentation.

My final report is in `report/CMPSC448_Project_Report.pdf`. I saved the experiment results and data details in `artifacts/`.

## Where I got my data

I used the public MT Bench questions and model responses. The dataset includes 80 questions from eight categories: writing, roleplay, reasoning, math, coding, extraction, STEM, and humanities. Each question has two response turns from the six model versions I selected.

I grouped the model versions like this:

- GPT: `gpt-3.5-turbo` and `gpt-4`
- Claude: `claude-v1` and `claude-instant-v1`
- Llama: `Llama-2-7b-chat` and `Llama-2-13b-chat`

I kept questions that had both responses from all six versions. This gave me 960 responses in total. I kept the number of examples equal across the three families so no family had an unfair advantage.

I got the data from these public sources:

- Original dataset: https://github.com/lm-sys/FastChat/tree/main/fastchat/llm_judge/data/mt_bench
- Public copy of the model responses: https://huggingface.co/spaces/lmsys/mt-bench/tree/main/data/mt_bench/model_answer
- Research paper: https://arxiv.org/abs/2306.05685

I saved the source information and file checksums in `artifacts/source_provenance.json`. I kept the raw responses out of my GitHub upload. Anyone who wants to share the raw responses should check the data and model usage terms first.

## How I prepared the data

I split the questions into training, validation, and test sets using a 60%, 20%, and 20% split. I used question IDs to make sure that every response to the same question stayed in the same set. This matters because the six models answered the same questions, and I did not want the test set to contain questions that the models had already seen during training.

I made three versions of the text for each experiment:

- Prompt only: I used just the user's question.
- Response only: I used just the answer written by the model.
- Prompt and response: I used the question and answer together.

I kept model names and labels out of the text given to the classifiers. I also built the word vocabulary from the training data only. For the second response turn, I used both user questions without including the model's earlier answer in the prompt.

For the extra credit experiment on new tasks, I kept all writing questions out of training and validation. I used them only for the final writing test.

## Models and training

I wrote both models in PyTorch. The CNN looks for patterns among nearby words. The LSTM reads the text in both directions to learn from the order of words. I trained both models using the same data splits so I could compare them fairly.

I used 64 dimensional word embeddings, a batch size of 32, a learning rate of 0.002, and up to eight training epochs. I chose the best version of each model using the validation results, not the test results. I used the saved model to measure the final test performance.

I recorded accuracy, macro F1, class results, and confusion matrices. I also calculated accuracy ranges by resampling at the question level. The full settings and saved results are in `artifacts/`.

## What I tested

### RQ1: Can I identify the model from its answer?

I trained and tested both the CNN and LSTM using only the model responses. The CNN reached 76.6% accuracy, and the LSTM reached 74.5% accuracy.

### RQ2: Does the user's question help?

I tested each model with the prompt alone, the response alone, and both together. That gave me six experiments in total. The response only setting worked best for both models. The prompt only setting was at 33.3% accuracy, which is the chance level for three equally sized groups.

### RQ3: Can the models handle a new type of question?

I trained on the other task categories and tested on writing questions that were not used during training. The CNN reached 73.3% accuracy on writing, and the LSTM reached 68.3%. This was my first extra credit question.

### RQ4: What makes the models' writing different?

I compared response length, word variety, and list formatting across the three families. I also removed some formatting from the text and tested the CNN again. Its macro F1 score dropped by 0.212 after that change. This was my second extra credit question.

The final report includes the full results, charts, and my explanation of what I found.

## What I learned

The responses gave my models more useful information than the questions alone. I also found that writing style and formatting can help a classifier tell the families apart. The test on writing questions showed that some of these patterns can carry over to a task that was not used in training.

I still have to be careful about how much I conclude from these results. Although I used 960 responses, they came from only 80 different questions. I also used older model versions from the public dataset. My results describe this experiment, not every version of these models. Removing formatting may also change parts of code or math answers, so that experiment does not isolate formatting perfectly.

## How I can run the project again

The experiments are already complete. I do not need to train the models again to submit my work. I included these steps so I can run the project again if needed.

On Windows, I can open PowerShell in the project folder and run:

```powershell
py -3.11 -m venv .venv
.\.venv\Scripts\python.exe -m pip install --upgrade pip
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe run_all.py --download --author "Ata Dural"
```

On macOS or Linux, I can run:

```bash
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python run_all.py --download --author "Ata Dural"
```

The script downloads the public question file and six model response files. If the download does not work, I can place these files in `data/raw/` and run the script without `--download`:

```text
data/raw/question.jsonl
data/raw/model_answer/gpt-3.5-turbo.jsonl
data/raw/model_answer/gpt-4.jsonl
data/raw/model_answer/claude-v1.jsonl
data/raw/model_answer/claude-instant-v1.jsonl
data/raw/model_answer/Llama-2-7b-chat.jsonl
data/raw/model_answer/Llama-2-13b-chat.jsonl
```

I can also run the unit tests with:

```powershell
.\.venv\Scripts\python.exe -m pytest -q
```

The unit tests use made up examples to check that the code works. I did not use those examples for the results in my report. Running the full training script again can replace saved results, so I will keep my completed report unless I mean to repeat the experiments.

## Files I included

- `src/` contains my data preparation, model, training, and testing code.
- `tests/` contains my unit tests.
- `docs/` contains supporting notes.
- `artifacts/` contains my saved results, source details, and data split information.
- `report/CMPSC448_Project_Report.pdf` is my final report.
- `run_all.py` runs the full project.
- `requirements.txt` lists the Python packages I used.
- `.gitignore` keeps local data, saved model files, and temporary files out of GitHub.

## How I will submit

I will upload my code, final report, and saved experiment details to a public GitHub repository. I will make sure the final PDF is inside `report/` and that the old draft is not included. I will open the repository link in a private browser window to make sure my instructor can view it. Then I will paste the GitHub repository URL into Canvas before my extended deadline.
