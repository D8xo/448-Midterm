"""Test data preparation, models, and result calculations."""
import json

import numpy as np
import pandas as pd
import pytest
import torch

from src.data import (MODEL_FAMILIES, domain_splits, partition, prepare_dataset,
                      question_splits, strip_formatting)
from src.experiments import assemble_text, bootstrap_ci, stylometric_features
from src.models import CNNClassifier, LSTMClassifier, TextDataset, Vocabulary


@pytest.fixture
def artificial_mtbench(tmp_path):
    raw = tmp_path / "raw"
    (raw / "model_answer").mkdir(parents=True)
    categories = ["writing", "roleplay", "reasoning", "math", "coding", "extraction",
                  "stem", "humanities"]
    questions = [{"question_id": i + 81, "category": categories[i // 10],
                  "turns": [f"first task {i}", f"follow-up task {i}"]} for i in range(80)]
    (raw / "question.jsonl").write_text("\n".join(json.dumps(r) for r in questions))
    for family, models in MODEL_FAMILIES.items():
        for model in models:
            items = [{"question_id": q["question_id"], "model_id": model,
                      "choices": [{"index": 0, "turns": [
                          f"{family} test response {q['question_id']}",
                          f"{family} test follow-up {q['question_id']}"]}]}
                     for q in questions]
            (raw / "model_answer" / f"{model}.jsonl").write_text("\n".join(json.dumps(i) for i in items))
    return raw, tmp_path / "prepared"


def test_prepare_and_balance(artificial_mtbench):
    raw, target = artificial_mtbench
    df = prepare_dataset(raw, target)
    assert len(df) == 960
    assert df.groupby("family").size().to_dict() == {"GPT": 320, "Claude": 320, "Llama": 320}
    assert len(df[df.question_id == 81]) == 12
    assert "[USER FOLLOW-UP]" in df.loc[df.turn == 2, "prompt"].iloc[0]


def test_question_grouping_and_domains(artificial_mtbench):
    df = prepare_dataset(*artificial_mtbench)
    main = question_splits(df)
    assert [len(main[x]) for x in ("train", "val", "test")] == [48, 16, 16]
    assert len(set(main["train"]) & set(main["test"])) == 0
    assert len(set(main["val"]) & set(main["test"])) == 0
    for part in main:
        assert partition(df, main, part).family.value_counts().nunique() == 1
    domain = domain_splits(df, "writing")
    assert [len(domain[x]) for x in ("train", "val", "test")] == [56, 14, 10]
    assert set(df[df.question_id.isin(domain["test"])].category) == {"writing"}
    assert "writing" not in set(df[df.question_id.isin(domain["train"])].category)


def test_sequence_models_forward():
    vocab = Vocabulary.build(["hello world sample", "another world example"])
    ds = TextDataset(["hello world sample", "another world example"], [0, 1], vocab, 15)
    xb = torch.stack([ds[0][0], ds[1][0]])
    lengths = torch.stack([ds[0][1], ds[1][1]])
    for model in (CNNClassifier(len(vocab)), LSTMClassifier(len(vocab))):
        logits = model(xb, lengths)
        assert logits.shape == (2, 3)
        assert torch.isfinite(logits).all()


def test_inputs_and_style_features():
    frame = pd.DataFrame({"prompt": ["Tell me why", "Tell me why"],
                          "output": ["# Heading\n- A response", "Plain response"]})
    assert assemble_text(frame, "input")[0] == assemble_text(frame, "input")[1]
    assert "Heading" not in assemble_text(frame, "input")[0]
    assert "Heading" in assemble_text(frame, "output")[0]
    assert "[ASSISTANT]" in assemble_text(frame, "input+output")[0]
    assert "#" not in strip_formatting(frame.output.iloc[0])
    assert stylometric_features(frame.output.iloc[0])["heading_line_count"] == 1


def test_bootstrap_bounds():
    target = np.array([0, 1, 2, 0, 1, 2])
    ci = bootstrap_ci(target, target, [1, 1, 1, 2, 2, 2], n_boot=20)
    assert ci == [1.0, 1.0]
