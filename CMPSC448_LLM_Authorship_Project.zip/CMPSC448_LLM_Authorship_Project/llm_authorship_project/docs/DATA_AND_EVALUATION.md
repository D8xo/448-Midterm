# How I prepared and tested my data

## Where I got the data

I used the public MT Bench questions and model responses from LMSYS FastChat. From `question.jsonl`, I read the question ID, task category, and two user questions. From each `model_answer/*.jsonl` file, I read the question ID, model name, and first recorded set of answers.

I used responses from six model versions, grouped into GPT, Claude, and Llama. I kept only questions that had both answer turns for all six versions. This gave me 80 questions and 960 responses, with 320 responses per family.

## Why I used MT Bench

I chose this dataset because every model answered the same questions. This was important for RQ2. If I had used separate questions for each model, the classifier might have guessed the family from the question instead of the response.

MT Bench also labels questions by task. I used those labels for RQ3 rather than guessing the task from the words in a response.

## How I split the questions

I split the 80 questions into 48 for training, 16 for validation, and 16 for testing. I kept both answer turns and all six model versions together for each question. That means a question in the test set did not also appear in training or validation. I used seed 448 and kept the same question split for the main comparisons.

For the prompt only experiment, I included just the user's questions. For the second turn, I included both user questions but no earlier model answer. I built the vocabulary from training data only.

## How I tested a new task for RQ3

I held out all 10 writing questions. I used 56 of the other questions for training and 14 for validation. I then tested both the CNN and LSTM on the 10 writing questions, which gave me 120 response examples.

This tells me how the models performed on writing in this dataset. It does not mean they would work equally well on every new task.

## How I checked writing features for RQ4

I measured things like response length, word variety, list lines, headings, punctuation, and the use of certain first person words. The pronoun count in my code includes `i`, `me`, `my`, and `mine`. It does not include `we`.

I also trained a CNN after removing common Markdown and list markers and making spacing consistent. I kept the question split, random seed, and model settings the same. Removing these markers can also change code or math text, so I cannot say that any change in accuracy came only from formatting.

## How I checked the results

I measured accuracy and Macro F1 for the test sets. I also saved scores for each family and confusion matrices. To estimate an accuracy range, I sampled test question IDs 500 times, keeping all responses to each selected question together. This made more sense than treating every response to the same question as unrelated.

I ran the main experiments with one random seed. The dataset is also limited to older model versions and 80 original questions. I would need more seeds and other datasets before drawing wider conclusions.

## What I saved

I kept the question splits, experiment settings, summary counts, results, and source file checksums in `artifacts/`. I did not use private chats. I left the original model responses out of the GitHub upload because anyone sharing them should first check the source terms.
